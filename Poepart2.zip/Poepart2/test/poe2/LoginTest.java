package poe2;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Login class
 * @author RC_Student_Lab
 */
public class LoginTest {
    
    private Login login;
    
    public LoginTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
        login = new Login();
    }
    
    @AfterEach
    public void tearDown() {
    }
    
    // ========== Username Tests ==========
    
    @Test
    public void testCheckUserName_ValidUsername() {
        System.out.println("checkUserName - Valid username with underscore");
        String userName = "kyl_1";
        boolean result = login.checkUserName(userName);
        assertTrue(result, "Username with underscore and 5 or fewer characters should be valid");
    }
    
    @Test
    public void testCheckUserName_InvalidUsername_TooLong() {
        System.out.println("checkUserName - Invalid username (too long)");
        String userName = "kyle!!!!!!!";
        boolean result = login.checkUserName(userName);
        assertFalse(result, "Username longer than 5 characters without underscore should be invalid");
    }
    
    @Test
    public void testCheckUserName_InvalidUsername_NoUnderscore() {
        System.out.println("checkUserName - Invalid username (no underscore)");
        String userName = "kyle";
        boolean result = login.checkUserName(userName);
        assertFalse(result, "Username without underscore should be invalid");
    }
    
    @Test
    public void testCheckUserName_EmptyUsername() {
        System.out.println("checkUserName - Empty username");
        String userName = "";
        boolean result = login.checkUserName(userName);
        assertFalse(result, "Empty username should be invalid");
    }
    
    // ========== Password Complexity Tests ==========
    
    @Test
    public void testCheckPasswordComplexity_ValidPassword() {
        System.out.println("checkPasswordComplexity - Valid complex password");
        String password = "Ch&&sec@ke99!";
        boolean result = login.checkPasswordComplexity(password);
        assertTrue(result, "Password meeting all complexity requirements should be valid");
    }
    
    @Test
    public void testCheckPasswordComplexity_InvalidPassword_TooShort() {
        System.out.println("checkPasswordComplexity - Invalid password (too short)");
        String password = "Pass1!";
        boolean result = login.checkPasswordComplexity(password);
        assertFalse(result, "Password shorter than 8 characters should be invalid");
    }
    
    @Test
    public void testCheckPasswordComplexity_InvalidPassword_NoCapital() {
        System.out.println("checkPasswordComplexity - Invalid password (no capital letter)");
        String password = "password1!";
        boolean result = login.checkPasswordComplexity(password);
        assertFalse(result, "Password without capital letter should be invalid");
    }
    
    @Test
    public void testCheckPasswordComplexity_InvalidPassword_NoNumber() {
        System.out.println("checkPasswordComplexity - Invalid password (no number)");
        String password = "Password!";
        boolean result = login.checkPasswordComplexity(password);
        assertFalse(result, "Password without number should be invalid");
    }
    
    @Test
    public void testCheckPasswordComplexity_InvalidPassword_NoSpecialChar() {
        System.out.println("checkPasswordComplexity - Invalid password (no special character)");
        String password = "Password1";
        boolean result = login.checkPasswordComplexity(password);
        assertFalse(result, "Password without special character should be invalid");
    }
    
    @Test
    public void testCheckPasswordComplexity_EmptyPassword() {
        System.out.println("checkPasswordComplexity - Empty password");
        String password = "";
        boolean result = login.checkPasswordComplexity(password);
        assertFalse(result, "Empty password should be invalid");
    }
    
    // ========== Register User Tests ==========
    
    @Test
    public void testRegisterUser_Success() {
        System.out.println("registerUser - Successful registration");
        String userName = "kyl_1";
        String password = "Ch&&sec@ke99!";
        String firstName = "John";
        String lastName = "Doe";
        
        String result = login.registerUser(userName, password, firstName, lastName);
        
        assertTrue(result.contains("success") || result.contains("captured"), 
                   "Registration with valid credentials should succeed");
    }
    
    @Test
    public void testRegisterUser_InvalidUsername() {
        System.out.println("registerUser - Invalid username");
        String userName = "invalidusername";
        String password = "Ch&&sec@ke99!";
        String firstName = "John";
        String lastName = "Doe";
        
        String result = login.registerUser(userName, password, firstName, lastName);
        
        assertTrue(result.contains("incorrectly formatted") || result.contains("invalid"), 
                   "Registration with invalid username should fail");
    }
    
    @Test
    public void testRegisterUser_InvalidPassword() {
        System.out.println("registerUser - Invalid password");
        String userName = "kyl_1";
        String password = "simple";
        String firstName = "John";
        String lastName = "Doe";
        
        String result = login.registerUser(userName, password, firstName, lastName);
        
        assertTrue(result.contains("does not meet") || result.contains("complexity"), 
                   "Registration with invalid password should fail");
    }
    
    @Test
    public void testRegisterUser_BothInvalid() {
        System.out.println("registerUser - Both username and password invalid");
        String userName = "invalidusername";
        String password = "simple";
        String firstName = "John";
        String lastName = "Doe";
        
        String result = login.registerUser(userName, password, firstName, lastName);
        
        assertFalse(result.contains("success"), 
                    "Registration with invalid credentials should not succeed");
    }
    
    // ========== Login User Tests ==========
    
    @Test
    public void testLoginUser_Success() {
        System.out.println("loginUser - Successful login");
        // First register a user
        String userName = "kyl_1";
        String password = "Ch&&sec@ke99!";
        String firstName = "John";
        String lastName = "Doe";
        
        login.registerUser(userName, password, firstName, lastName);
        
        // Then attempt login with same credentials
        boolean result = login.loginUser(userName, password);
        
        assertTrue(result, "Login with matching credentials should succeed");
    }
    
    @Test
    public void testLoginUser_WrongUsername() {
        System.out.println("loginUser - Wrong username");
        // Register a user
        String registeredUsername = "kyl_1";
        String registeredPassword = "Ch&&sec@ke99!";
        String firstName = "John";
        String lastName = "Doe";
        
        login.registerUser(registeredUsername, registeredPassword, firstName, lastName);
        
        // Attempt login with wrong username
        String attemptUsername = "wrong_user";
        boolean result = login.loginUser(attemptUsername, registeredPassword);
        
        assertFalse(result, "Login with wrong username should fail");
    }
    
    @Test
    public void testLoginUser_WrongPassword() {
        System.out.println("loginUser - Wrong password");
        // Register a user
        String registeredUsername = "kyl_1";
        String registeredPassword = "Ch&&sec@ke99!";
        String firstName = "John";
        String lastName = "Doe";
        
        login.registerUser(registeredUsername, registeredPassword, firstName, lastName);
        
        // Attempt login with wrong password
        String attemptPassword = "WrongPass1!";
        boolean result = login.loginUser(registeredUsername, attemptPassword);
        
        assertFalse(result, "Login with wrong password should fail");
    }
    
    @Test
    public void testLoginUser_BothWrong() {
        System.out.println("loginUser - Both username and password wrong");
        // Register a user
        String registeredUsername = "kyl_1";
        String registeredPassword = "Ch&&sec@ke99!";
        String firstName = "John";
        String lastName = "Doe";
        
        login.registerUser(registeredUsername, registeredPassword, firstName, lastName);
        
        // Attempt login with wrong credentials
        String attemptUsername = "wrong_user";
        String attemptPassword = "WrongPass1!";
        boolean result = login.loginUser(attemptUsername, attemptPassword);
        
        assertFalse(result, "Login with wrong username and password should fail");
    }
    
    // ========== Return Login Status Tests ==========
    
    @Test
    public void testReturnLoginStatus_Success() {
        System.out.println("returnLoginStatus - Successful login message");
        String firstName = "John";
        String lastName = "Doe";
        
        String result = login.returnLoginStatus(true, firstName, lastName);
        
        assertTrue(result.contains("Welcome") && result.contains(firstName) && result.contains(lastName),
                   "Successful login should return welcome message with name");
    }
    
    @Test
    public void testReturnLoginStatus_Failure() {
        System.out.println("returnLoginStatus - Failed login message");
        String firstName = "John";
        String lastName = "Doe";
        
        String result = login.returnLoginStatus(false, firstName, lastName);
        
        assertTrue(result.contains("unsuccessful") || result.contains("failed"),
                   "Failed login should return unsuccessful message");
    }
}