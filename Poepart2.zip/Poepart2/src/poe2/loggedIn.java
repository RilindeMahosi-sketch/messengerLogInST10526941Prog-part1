package poe2;
import java.util.ArrayList; 
import javax.swing.JOptionPane; 
import java.time.LocalDateTime; 

public class loggedIn {
   private ArrayList messages = new ArrayList<>();
   private ArrayList pendingMessages = new ArrayList<>(); 

public void Choice() { 
    do { 
        String input = JOptionPane.showInputDialog(null,  
            "Welcome to QuickChat.\n1. Send Messages\n2. Show Recently Sent Messages\n3. Quit\nEnter your choice:"); 
        if (input == null) { 
            JOptionPane.showMessageDialog(null, "Exiting..."); 
            return; 
        } 
 
        int choice; 
        try { 
            choice = Integer.parseInt(input.trim()); 
        } catch (NumberFormatException e) { 
            JOptionPane.showMessageDialog(null, "Please enter a valid number (1-3)."); 
            continue; 
        } 
 
        switch (choice) { 
            case 1: 
                String numInput = JOptionPane.showInputDialog(null, "Enter the number of messages:"); 
                if (numInput == null) { 
                    JOptionPane.showMessageDialog(null, "Cancelled. Returning to menu."); 
                    continue; 
                } 
                int numMessages; 
                try { 
                    numMessages = Integer.parseInt(numInput.trim()); 
                    if (numMessages <= 0) { 
                        JOptionPane.showMessageDialog(null, "Please enter a positive number."); 
                        continue; 
                    } 
                } catch (NumberFormatException e) { 
                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid integer."); 
                    continue; 
                } 
 
                for (int i = 0; i < numMessages; i++) { 
                    // Input message content 
                    String content=""; 
                    boolean validContent = false; 
                    while (!validContent) { 
                        content = JOptionPane.showInputDialog(null,  
                            "Enter message " + (i + 1) + " content (max 50 characters):"); 
                        if (content == null) { 
                            JOptionPane.showMessageDialog(null, "Message input cancelled."); 
                            break; 
                        } 
                        content = content.trim(); 
                        if (content.isEmpty()) { 
                            JOptionPane.showMessageDialog(null,  
                                "Message content cannot be empty."); 
                        } else if (content.length() > 50) { 
                            JOptionPane.showMessageDialog(null,  
                                "Please enter a message of 50 characters or less."); 
                        } else { 
                            validContent = true; 
                            JOptionPane.showMessageDialog(null, "Message captured"); 
                        } 
                    } 
                    if (!validContent) { 
                        continue; 
                    } 
 
                    // Input recipient cell number 
                    String recipient=""; 
                    boolean validRecipient = false; 
                    while (!validRecipient) { 
                        recipient = JOptionPane.showInputDialog(null,  
                            "Enter recipient cell number (e.g., +27123456789):"); 
                        if (recipient == null) { 
                            JOptionPane.showMessageDialog(null, "Recipient input cancelled."); 
                            break; 
                        } 
                        recipient = recipient.trim(); 
                        // Temporary message for validation 
                        Message tempMessage = new Message(content, recipient, "", "0821234567"); 
                        if (tempMessage.checkRecipientCell() == 0) { 
                            validRecipient = true; 
                        } else { 
                            JOptionPane.showMessageDialog(null,  
                                "Invalid format. Must be exactly 12 characters starting with +27 (e.g., +27123456789)."); 
                        } 
                    } 
                    if (!validRecipient) { 
                        continue; 
                    } 
 
                    // Create message with timestamp 
                    String timestamp = LocalDateTime.now().toString(); 
                    Message message = new Message(content, recipient, timestamp, "0821234567"); 
 
                    // Validate message ID 
                    if (!message.checkMessageID()) { 
                        JOptionPane.showMessageDialog(null,  
                            "Message ID generation failed (not exactly 10 digits). Please try again."); 
                        continue; 
                    } 
 
                    // Generate message hash (called in constructor, but ensure it's set) 
                    String messageHash = message.getMessageHash(); 
                    if (messageHash == null || messageHash.isEmpty()) { 
                        JOptionPane.showMessageDialog(null,  
                            "Message hash generation failed. Please try again."); 
                        continue; 
                    } 
 
                    // Simulate user action choice for send/store/disregard using JOptionPane 
                    String actionInput = JOptionPane.showInputDialog(null,  
                        "Choose an action for the message:\n1. Send Message\n2. Disregard Message\n3. Store Message to send later\nEnter 1-3:"); 
                    if (actionInput == null) { 
                        JOptionPane.showMessageDialog(null, "Action cancelled. Message disregarded."); 
                        continue; 
                    } 
                    int action; 
                    try { 
                        action = Integer.parseInt(actionInput.trim()); 
                    } catch (NumberFormatException e) { 
                        JOptionPane.showMessageDialog(null, "Invalid action. Message disregarded."); 
                        continue; 
                    } 
 
                    String actionResult; 
                    switch (action) { 
                        case 1: 
                            Message.getSentMessages().add(message); 
                            Message.incrementTotalMessagesSent(); 
                            messages.add(message); 
                            actionResult = "Message sent successfully."; 
                            break; 
                        case 2: 
                            actionResult = "Message disregarded."; 
                            continue; 
                        case 3: 
                            Message.getSentMessages().add(message); 
                            Message.incrementTotalMessagesSent(); 
                            pendingMessages.add(message); 
                            actionResult = "Message stored for later sending."; 
                            break; 
                        default: 
                            actionResult = "Invalid choice. Message disregarded."; 
                            continue; 
                    } 
 
                    JOptionPane.showMessageDialog(null, actionResult); 
 
                    if (actionResult.contains("sent successfully")) { 
                        JOptionPane.showMessageDialog(null,  
                            "Message Details:\n" + 
                            "Recipient: " + message.getRecipient() + "\n" + 
                            "Message ID: " + message.getId() + "\n" + 
                            "Message Hash: " + messageHash + "\n" + 
                            "Content: " + message.getContent() + "\n" + 
                            "Timestamp: " + timestamp); 
                    } else if (actionResult.contains("stored for later sending")) { 
                        JOptionPane.showMessageDialog(null,  
                            "Message stored for later sending:\n" + 
                            "Recipient: " + message.getRecipient() + "\n" + 
                            "Message ID: " + message.getId() + "\n" + 
                            "Message Hash: " + messageHash + "\n" + 
                            "Content: " + message.getContent() + "\n" + 
                            "Timestamp: " + timestamp); 
                    } 
                } 
                JOptionPane.showMessageDialog(null,  
                    "Total number of messages sent: " + Message.returnTotalMessages() +  
                    "\nMessages processed."); 
                 
                // Optionally store to JSON after processing 
                int saveChoice = JOptionPane.showConfirmDialog(null,  
                    "Do you want to save messages to JSON file?",  
                    "Save Messages",  
                    JOptionPane.YES_NO_OPTION); 
                if (saveChoice == JOptionPane.YES_OPTION) { 
                    Message.storeMessage(messages, pendingMessages); 
                } 
                break; 
 
            case 2: 
                ArrayList<Message> sentMsgs = Message.printMessages(); 
                if (sentMsgs.isEmpty()) { 
                    JOptionPane.showMessageDialog(null, "No messages sent yet."); 
                } else { 
                    StringBuilder msgDisplay = new StringBuilder("Recently Sent Messages:\n"); 
                    for (Message msg : sentMsgs) { 
                        msgDisplay.append("Recipient: ").append(msg.getRecipient()) 
                                 .append("\nMessage ID: ").append(msg.getId()) 
                                 .append("\nMessage Hash: ").append(msg.getMessageHash()) 
                                 .append("\nContent: ").append(msg.getContent()) 
                                 .append("\nTimestamp: ").append(msg.getTimestamp()) 
                                 .append("\n\n"); 
                    } 
                    JOptionPane.showMessageDialog(null, "Coming soon"); 
                } 
                break; 
 
            case 3: 
                int exitSaveChoice = JOptionPane.showConfirmDialog(null,  
                    "Do you want to save messages to JSON file before exiting?",  
                    "Save and Exit",  
                    JOptionPane.YES_NO_OPTION); 
                if (exitSaveChoice == JOptionPane.YES_OPTION) { 
                    Message.storeMessage(messages, pendingMessages); 
                } 
                JOptionPane.showMessageDialog(null, "Exiting..."); 
                return; 
 
            default: 
                JOptionPane.showMessageDialog(null, "Invalid choice. Please enter 1, 2, or 3."); 
        } 
    } while (true); 
} 
  

} 