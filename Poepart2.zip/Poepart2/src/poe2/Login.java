package poe2;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Login {
    private String registeredUsername;
    private String registeredPassword;
    private String registeredFirstName;
    private String registeredLastName;
    
    public boolean checkUserName(String userName) {
        return userName != null && userName.contains("_") && userName.length() <= 5;
    }
    
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasNumber = false, hasUpper = false, hasSpecial = false;
        for (char c : password.toCharArray()) {
            if (Character.isDigit(c)) hasNumber = true;
            else if (Character.isUpperCase(c)) hasUpper = true;
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        return hasNumber && hasUpper && hasSpecial;
    }
    
    public String registerUser(String userName, String password, String firstName, String lastName) {
        String passMessage;
        String nameMessage;
        
        // Check password complexity
        if (checkPasswordComplexity(password)) {
            this.registeredPassword = password;
            passMessage = "Password successfully captured.";
        } else {
            passMessage = "Password does not meet complexity requirements. Please ensure that the password contains at least 8 characters, "
                    + "a capital letter, a number, and a special character.";
        }
        
        // Check username format
        if (checkUserName(userName)) {
            this.registeredUsername = userName;
            nameMessage = "Username successfully captured.";
        } else {
            nameMessage = "Username is not correctly formatted, please ensure that your "
                    + "username contains an underscore and is no more than 5 characters in length.";
        }
        
        // Store first and last name
        this.registeredFirstName = firstName;
        this.registeredLastName = lastName;
        
        return nameMessage + "\n" + passMessage;
    }
    
    public boolean loginUser(String userName, String password) {
        // Check if credentials match registered credentials
        if (registeredUsername != null && registeredPassword != null) {
            return userName.equals(registeredUsername) && password.equals(registeredPassword);
        }
        return false;
    }
    
    public String returnLoginStatus(boolean loginSuccess, String firstName, String lastName) {
        if (loginSuccess) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, login unsuccessful.";
        }
    }
    
    // Interactive login method for console use
    public boolean loginUserInteractive() {
        Scanner in = new Scanner(System.in);
        boolean loginSuccess = false;
        
        // Loop until successful login or user chooses to exit
        while (!loginSuccess) {
            System.out.println("\n*** LOGIN ***");
            System.out.print("Enter the username you used to register: ");
            String userName = in.nextLine();
            System.out.print("Enter the password you used to register: ");
            String password = in.nextLine();
          
            if (userName.equals(registeredUsername) && password.equals(registeredPassword)) {
                loginSuccess = true;
                System.out.println(returnLoginStatus(true, registeredFirstName, registeredLastName));
            } else {
                System.out.println("Username and/or password incorrect, please try again");
                System.out.print("Would you like to try again? (yes/no): ");
                String tryAgain = in.nextLine().trim().toLowerCase();
                if (!tryAgain.equals("yes")) {
                    break;
                }
            }
        }
        
        return loginSuccess;
    }
    
    // Getters for registered information
    public String getRegisteredUsername() {
        return registeredUsername;
    }
    
    public String getRegisteredFirstName() {
        return registeredFirstName;
    }
    
    public String getRegisteredLastName() {
        return registeredLastName;
    }
}