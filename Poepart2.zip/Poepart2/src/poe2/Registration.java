package poe2;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Registration {

    public static void main(String[] args) {
        new Registration().startRegistration();  
    }
    
    public void startRegistration() {
        Login loginSystem = new Login();
        
        String firstName = getNonEmptyInput("Please enter your first name");
        if (firstName == null) return;

        String lastName = getNonEmptyInput("Please enter your last name");
        if (lastName == null) return;

        String userName = getValidUsername();
        if (userName == null) return;

        String password = getValidPassword();
        if (password == null) return;

        String phoneNumber = getValidPhoneNumber();
        if (phoneNumber == null) return;
        
        // Register the user with the login system
        String registrationResult = loginSystem.registerUser(userName, password, firstName, lastName);
        
        JOptionPane.showMessageDialog(null,
                "Registration Successful!\n" +
                "First Name: " + firstName + "\n" +
                "Last Name: " + lastName + "\n" +
                "Username: " + userName + "\n" +
                "Phone: " + phoneNumber + "\n\n" +
                registrationResult);
        
        // Proceed to login
        boolean loginSuccess = loginSystem.loginUserInteractive();
        
        if (loginSuccess) {
            loggedIn loggedIn = new loggedIn();
            loggedIn.Choice();
        }
    }

    private String getNonEmptyInput(String prompt) {
        String input;
        do {
            input = JOptionPane.showInputDialog(prompt);
            if (input == null) return null;
            if (input.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Input cannot be empty. Please try again.");
            }
        } while (input.trim().isEmpty());
        return input.trim();
    }

    private String getValidUsername() {
        String userName;
        do {
            userName = JOptionPane.showInputDialog(null,
                    "Enter username (must be 5 or less characters and contain '_'):");
            if (userName == null) return null;
        } while (!isValidUsername(userName));
        return userName.trim();
    }

    private String getValidPassword() {
        String password;
        do {
            password = JOptionPane.showInputDialog(null,
                    "Enter password (At least 8 characters, with capital letter, a number, and special character):");
            if (password == null) return null;
        } while (!isValidPassword(password));
        
        return password;
    }

    private String getValidPhoneNumber() {
        String phoneNumber;
        do {
            phoneNumber = JOptionPane.showInputDialog(null,
                    "Enter phone number (+27 (International country code) followed by exactly 9 digits, e.g., +27123456789):");
            if (phoneNumber == null) return null;
        } while (!isValidPhoneNumber(phoneNumber));
        
        return phoneNumber.trim();
    }

    public boolean isValidUsername(String username) {
        if (username == null || username.trim().isEmpty() || username.length() > 5 || !username.contains("_")) {
            JOptionPane.showMessageDialog(null,
                    "Username is not correctly formatted, " +
                    "please ensure that your username contains an underscore and is no more than five characters in length.");
            return false;
        }
        return true;
    }

    public boolean isValidPassword(String password) {
        if (password == null || password.length() < 8) {
            JOptionPane.showMessageDialog(null,
                    "Password is not correctly formatted; " +
                    "please ensure that the password contains:\n" +
                    "- At least eight characters\n" +
                    "- A capital letter\n" +
                    "- A number\n" +
                    "- A special character");
            return false;
        }
        
        boolean hasUpper = false, hasDigit = false, hasSpecial = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        
        if (!hasUpper || !hasDigit || !hasSpecial) {
            JOptionPane.showMessageDialog(null,
                    "Password is not correctly formatted; " +
                    "please ensure that the password contains:\n" +
                    "- At least eight characters\n" +
                    "- A capital letter\n" +
                    "- A number\n" +
                    "- A special character");
            return false;
        }
        
        return true;
    }

    public boolean isValidPhoneNumber(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.length() != 12) {
            JOptionPane.showMessageDialog(null,
                    "Cell phone number incorrectly formatted; " +
                    "must be 12 characters (+27 followed by 9 digits).");
            return false;
        }
        
        if (!phoneNumber.startsWith("+27") || !phoneNumber.substring(3).matches("\\d{9}")) {
            JOptionPane.showMessageDialog(null,
                    "Cell phone number incorrectly formatted; " +
                    "or does not contain international code.");
            return false;
        }
        
        return true;
    }
}