package portforlio.pkg3;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Login {
private String registeredUsername;
    private String registeredPassword;
    private String firstName;
    private String lastName;

    public void registerUser(String username, String password, String firstName, String lastName) {
        this.registeredUsername = username;
        this.registeredPassword = password;
        this.firstName = firstName;
        this.lastName = lastName;

        JOptionPane.showMessageDialog(null,
            "Registration Successful!\n\nWelcome " + firstName + " " + lastName + "!\nUsername: " + username,
            "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    public boolean loginUser() {
        if (registeredUsername == null) {
            JOptionPane.showMessageDialog(null, "No registered user found!", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        for (int attempts = 1; attempts <= 3; attempts++) {
            String username = JOptionPane.showInputDialog(null,
                "LOGIN (" + attempts + "/3)\nEnter username:");
            if (username == null) return false;

            String password = JOptionPane.showInputDialog(null, "Enter password:");
            if (password == null) return false;

            if (username.equals(registeredUsername) && password.equals(registeredPassword)) {
                JOptionPane.showMessageDialog(null,
                    "Login Successful!\n\nWelcome back, " + firstName + " " + lastName + "!",
                    "Welcome", JOptionPane.INFORMATION_MESSAGE);
                return true;
            } else {
                JOptionPane.showMessageDialog(null,
                    "Wrong username or password.\nAttempts left: " + (3 - attempts),
                    "Login Failed", JOptionPane.WARNING_MESSAGE);
            }
        }

        JOptionPane.showMessageDialog(null, "Too many failed attempts.\nAccess denied.", "Blocked", JOptionPane.ERROR_MESSAGE);
        return false;
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }

    public String getUsername() {
        return registeredUsername;
    }
}
