package portforlio.pkg3;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.JOptionPane;
import org.json.JSONArray;
import org.json.JSONObject;

public class Message {
    private String recipient;
    private String content;
    private String messageID;
    private String messageHash;
    private String timestamp;
    private static int totalSentCounter = 0;

    public Message(String content, String recipient) {
        this.content = content.trim();
        this.recipient = recipient.trim();
        this.timestamp = LocalDateTime.now().toString();
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
    }

    private String generateMessageID() {
        Random r = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(r.nextInt(10));
        }
        return id.toString();
    }

    private String createMessageHash() {
        String[] words = content.split("\\s+");
        String first = words.length > 0 ? words[0] : "";
        String last = words.length > 1 ? words[words.length - 1] : first;
        String prefix = messageID.substring(0, 2);
        int wordCount = words.length;
        return (prefix + ":" + wordCount + ":" + first + last).toUpperCase();
    }

    public boolean checkMessageID() {
        return messageID.matches("\\d{10}");
    }

    public int checkRecipientCell() {
        return recipient.matches("^\\+27\\d{9}$") ? 0 : -1;
    }

    public static void incrementTotalMessagesSent() {
        totalSentCounter++;
    }

    public static int returnTotalMessages() {
        return totalSentCounter;
    }

    // JSON Save Method
    public static void storeMessage(ArrayList<Message> sent, ArrayList<Message> stored) {
        JSONObject root = new JSONObject();
        JSONArray sentJson = new JSONArray();
        JSONArray storedJson = new JSONArray();

        for (Message m : sent) {
            JSONObject o = new JSONObject();
            o.put("recipient", m.recipient);
            o.put("content", m.content);
            o.put("messageID", m.messageID);
            o.put("messageHash", m.messageHash);
            o.put("timestamp", m.timestamp);
            sentJson.put(o);
        }

        for (Message m : stored) {
            JSONObject o = new JSONObject();
            o.put("recipient", m.recipient);
            o.put("content", m.content);
            o.put("messageID", m.messageID);
            o.put("messageHash", m.messageHash);
            o.put("timestamp", m.timestamp);
            storedJson.put(o);
        }

        root.put("Sent_Messages", sentJson);
        root.put("Stored_Messages", storedJson);
        root.put("total_sent", totalSentCounter);
        root.put("export_date", LocalDateTime.now());

        try (FileWriter file = new FileWriter("QuickChat_Messages.json")) {
            file.write(root.toString(4));
            JOptionPane.showMessageDialog(null,
                "All messages saved successfully!\nFile: QuickChat_Messages.json",
                "Saved", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Save failed: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Getters
    public String getRecipient() { return recipient; }
    public String getContent() { return content; }
    public String getId() { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getTimestamp() { return timestamp.substring(0, 19).replace("T", " "); }
}