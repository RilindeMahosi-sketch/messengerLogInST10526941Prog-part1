package portforlio.pkg3;
import javax.swing.JOptionPane;

public class Registration {

  
    public static void main(String[] args) {
 new Registration().startRegistration();
    }

    public void startRegistration() {
        String firstName = getNonEmptyInput("Please enter your first name:");
        if (firstName == null) return;

        String lastName = getNonEmptyInput("Please enter your last name:");
        if (lastName == null) return;

        String username = getValidUsername();
        if (username == null) return;

        String password = getValidPassword();
        if (password == null) return;

        String phoneNumber = getValidPhoneNumber();
        if (phoneNumber == null) return;

        // Register user via Login class
        Login login = new Login();
        login.registerUser(username, password, firstName, lastName);

        // Attempt login
        if (login.loginUser()) {
            Loggedin app = new Loggedin(login.getUsername(), login.getFullName());
            app.Choice();
        } else {
            JOptionPane.showMessageDialog(null, "Access denied. Goodbye!");
        }
    }

    private String getNonEmptyInput(String prompt) {
        String input;
        do {
            input = JOptionPane.showInputDialog(null, prompt);
            if (input == null) return null;
            input = input.trim();
            if (input.isEmpty()) {
                JOptionPane.showMessageDialog(null, "This field cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (input.isEmpty());
        return input;
    }

    private String getValidUsername() {
        String username;
        do {
            username = JOptionPane.showInputDialog("Enter username (max 5 chars, must contain '_'):");
            if (username == null) return null;
            username = username.trim();

            if (username.length() > 5 || !username.contains("_")) {
                JOptionPane.showMessageDialog(null,
                    "Invalid username!\n• Max 5 characters\n• Must contain an underscore (_)",
                    "Username Error", JOptionPane.ERROR_MESSAGE);
                username = "";
            }
        } while (username.isEmpty());
        return username;
    }

    private String getValidPassword() {
        String password;
        boolean hasUpper = false, hasDigit = false, hasSpecial = false;

        do {
            password = JOptionPane.showInputDialog(
                "Enter password (8+ chars)\nMust contain:\n• Uppercase letter\n• Number\n• Special character (!@#$%^&* etc.)");
            if (password == null) return null;

            hasUpper = hasDigit = hasSpecial = false;
            if (password.length() < 8) {
                JOptionPane.showMessageDialog(null, "Password must be at least 8 characters long.");
                continue;
            }
            for (char c : password.toCharArray()) {
                if (Character.isUpperCase(c)) hasUpper = true;
                if (Character.isDigit(c)) hasDigit = true;
                if ("!@#$%^&*()_+-=[]{}|;:,.<>?".indexOf(c) >= 0) hasSpecial = true;
            }

            if (!(hasUpper && hasDigit && hasSpecial)) {
                JOptionPane.showMessageDialog(null,
                    "Password must contain:\n• At least one uppercase letter\n• One number\n• One special character");
            }
        } while (password.length() < 8 || !(hasUpper && hasDigit && hasSpecial));
        return password;
    }

    private String getValidPhoneNumber() {
        String phone;
        do {
            phone = JOptionPane.showInputDialog("Enter phone number\nFormat: +27123456789");
            if (phone == null) return null;

            if (!phone.matches("^\\+27\\d{9}$")) {
                JOptionPane.showMessageDialog(null,
                    "Invalid format!\nMust start with +27 and have exactly 9 digits after.\nExample: +27812345678",
                    "Phone Error", JOptionPane.ERROR_MESSAGE);
                phone = "";
            }
        } while (phone.isEmpty());
        return phone;
    }
}
