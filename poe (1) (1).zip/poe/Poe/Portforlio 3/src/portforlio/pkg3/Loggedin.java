package portforlio.pkg3;
import java.util.ArrayList; 
import javax.swing.JOptionPane; 
import java.time.LocalDateTime; 

public class Loggedin {

    private final String username;
    private final String fullName;

    // Required arrays from your first image
    private final ArrayList<Message> sentMessages = new ArrayList<>();
    private final ArrayList<Message> disregardedMessages = new ArrayList<>();
    private final ArrayList<Message> storedMessages = new ArrayList<>();
    private final ArrayList<String> messageHashes = new ArrayList<>();
    private final ArrayList<String> messageIDs = new ArrayList<>();

    public Loggedin(String username, String fullName) {
        this.username = username;
        this.fullName = fullName;
        return;
    }

    public void Choice() {
        String[] menu = {
            "1. Send Messages",
            "2. Show Recently Sent Messages",
            "3. Display sender and recipient of all sent messages",
            "4. Display the longest sent message",
            "5. Search for a message ID and display recipient & message",
            "6. Search for all messages sent to a particular recipient",
            "7. Delete a message using the message ID",
            "8. Display full report of all sent messages",
            "9. Save to JSON & Exit"
        };

        while (true) {
            String choice = (String) JOptionPane.showInputDialog(null,
                "Welcome " + fullName + " (@" + username + ")\n\nChoose an option:",
                "QuickChat - Main Menu", JOptionPane.PLAIN_MESSAGE, null, menu, menu[0]);

            if (choice == null || choice.startsWith("9")) {
                saveAndExit();
                return;
            }

            int option = Integer.parseInt(choice.substring(0, 1));

            switch (option) {
                case 0-> loadTestData();
                case 1 -> sendMessagesBatch();
                case 2 -> showRecentlySentMessages();
                case 3 -> displaySenderAndRecipient();
                case 4 -> displayLongestSentMessage();
                case 5 -> searchMessageByID();
                case 6 -> searchMessagesByRecipient();
                case 7 -> deleteMessageByID();
                case 8 -> displayFullReport();
            }
        }
    }
    
    private void loadTestData() {
    // Test Data Message 1 – Sent
    Message m1 = new Message("Did you get the cake?", "+27834557896");
    sentMessages.add(m1);
    messageIDs.add(m1.getId());
    messageHashes.add(m1.getMessageHash());
    Message.incrementTotalMessagesSent();

    // Test Data Message 2 – Stored
    Message m2 = new Message("Where are you? You are late! I have asked you to be on time.", "+27838884567");
    storedMessages.add(m2);
    messageIDs.add(m2.getId());
    messageHashes.add(m2.getMessageHash());

    // Test Data Message 3 – Disregard
    Message m3 = new Message("Yohoooo, I am at your gate.", "+27834484567");
    disregardedMessages.add(m3);
    messageIDs.add(m3.getId());
    messageHashes.add(m3.getMessageHash());

    // Test Data Message 4 – Sent
    Message m4 = new Message("It is dinner time !", "0838884567"); // Note: without +27 → will be invalid on purpose if you want to test validation
    sentMessages.add(m4);
    messageIDs.add(m4.getId());
    messageHashes.add(m4.getMessageHash());
    Message.incrementTotalMessagesSent();

    // Test Data Message 5 – Stored
    Message m5 = new Message("Ok, I am leaving without you.", "+27838884567");
    storedMessages.add(m5);
    messageIDs.add(m5.getId());
    messageHashes.add(m5.getMessageHash());

    JOptionPane.showMessageDialog(null, "5 Test Messages Loaded Successfully!\n2 Sent | 2 Stored | 1 Disregarded");
}

    // ==================== 1. Send Messages ====================
    private void sendMessagesBatch() {
        String numStr = JOptionPane.showInputDialog("How many messages do you want to create?");
        if (numStr == null) return;
        int count = Integer.parseInt(numStr.trim());

        for (int i = 1; i <= count; i++) {
            // Content
            String content;
            do {
                content = JOptionPane.showInputDialog("Message " + i + " content (max 50 chars):");
                if (content == null) return;
                if (content.trim().isEmpty() || content.length() > 50) {
                    JOptionPane.showMessageDialog(null, "Content must be 1–50 characters!");
                }
            } while (content.trim().isEmpty() || content.length() > 50);
            content = content.trim();

            // Recipient
            String recipient;
            do {
                recipient = JOptionPane.showInputDialog("Recipient phone number (+27XXXXXXXXX):");
                if (recipient == null) return;
                if (new Message(content, recipient).checkRecipientCell() != 0) {
                    JOptionPane.showMessageDialog(null, "Invalid! Must be +27 followed by exactly 9 digits.");
                }
            } while (new Message(content, recipient).checkRecipientCell() != 0);

            Message msg = new Message(content, recipient);

            // Always collect ID and Hash
            messageIDs.add(msg.getId());
            messageHashes.add(msg.getMessageHash());

            // Action choice
            String[] actions = {"Send", "Store for later", "Disregard"};
            int action = JOptionPane.showOptionDialog(null,
                "Message ready!\n\n" + content + "\nTo: " + recipient + "\nID: " + msg.getId(),
                "What do you want to do?", JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, actions, actions[0]);

            if (action == 0) { // Send
                sentMessages.add(msg);
                Message.incrementTotalMessagesSent();
                JOptionPane.showMessageDialog(null, "Message SENT successfully!");
            } else if (action == 1) { // Store
                storedMessages.add(msg);
                JOptionPane.showMessageDialog(null, "Message STORED for later.");
            } else { // Disregard or cancel
                disregardedMessages.add(msg);
                JOptionPane.showMessageDialog(null, "Message disregarded.");
            }
        }
    }

    // ==================== 2. Show Recently Sent Messages ====================
    private void showRecentlySentMessages() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages sent yet.");
            return;
        }
        StringBuilder sb = new StringBuilder("=== RECENTLY SENT MESSAGES ===\n\n");
        for (Message m : sentMessages) {
            sb.append("To: ").append(m.getRecipient()).append("\n")
              .append("ID: ").append(m.getId()).append("\n")
              .append("Hash: ").append(m.getMessageHash()).append("\n")
              .append("Content: ").append(m.getContent()).append("\n")
              .append("Time: ").append(m.getTimestamp()).append("\n")
              .append("─────────────────────────────\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    // ==================== 3. Sender & Recipient of all sent messages ====================
    private void displaySenderAndRecipient() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages.");
            return;
        }
        StringBuilder sb = new StringBuilder("Sender: " + fullName + " (@" + username + ")\n\nRecipients:\n\n");
        for (Message m : sentMessages) {
            sb.append("→ ").append(m.getRecipient()).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    // ==================== 4. Longest sent message ====================
    private void displayLongestSentMessage() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages sent yet.");
            return;
        }
        Message longest = sentMessages.get(0);
        for (Message m : sentMessages) {
            if (m.getContent().length() > longest.getContent().length()) {
                longest = m;
            }
        }
        JOptionPane.showMessageDialog(null,
            "LONGEST SENT MESSAGE\n\n" +
            "Length: " + longest.getContent().length() + " characters\n" +
            "Content: " + longest.getContent() + "\n" +
            "To: " + longest.getRecipient() + "\n" +
            "ID: " + longest.getId());
    }

    // ==================== 5. Search by Message ID ====================
    private void searchMessageByID() {
        String id = JOptionPane.showInputDialog("Enter Message ID to search:");
        if (id == null || id.trim().isEmpty()) return;

        for (Message m : sentMessages) {
            if (m.getId().equals(id.trim())) {
                JOptionPane.showMessageDialog(null,
                    "Message Found!\n\n" +
                    "Recipient: " + m.getRecipient() + "\n" +
                    "Content: " + m.getContent() + "\n" +
                    "Time: " + m.getTimestamp());
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found in sent messages.");
    }

    // ==================== 6. Search by Recipient ====================
    private void searchMessagesByRecipient() {
        String recipient = JOptionPane.showInputDialog("Enter recipient phone number:");
        if (recipient == null) return;

        ArrayList<Message> found = new ArrayList<>();
        for (Message m : sentMessages) {
            if (m.getRecipient().equals(recipient.trim())) {
                found.add(m);
            }
        }

        if (found.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages sent to " + recipient);
            return;
        }

        StringBuilder sb = new StringBuilder("Messages sent to " + recipient + ":\n\n");
        for (Message m : found) {
            sb.append("ID: ").append(m.getId())
              .append(" | ").append(m.getContent())
              .append(" | ").append(m.getTimestamp()).append("\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString());
    }

    // ==================== 7. Delete by Message ID ====================
    private void deleteMessageByID() {
        String id = JOptionPane.showInputDialog("Enter Message ID to DELETE:");
        if (id == null || id.trim().isEmpty()) return;

        boolean removed = sentMessages.removeIf(m -> m.getId().equals(id.trim()));
        if (removed) {
            messageIDs.remove(id.trim());
            JOptionPane.showMessageDialog(null, "Message " + id + " deleted successfully.");
        } else {
            JOptionPane.showMessageDialog(null, "Message ID not found.");
        }
    }

    // ==================== 8. Full Report ====================
    private void displayFullReport() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to report.");
            return;
        }
        StringBuilder report = new StringBuilder("=== FULL SENT MESSAGES REPORT ===\n");
        report.append("Total Sent: ").append(sentMessages.size()).append("\n\n");

        int num = 1;
        for (Message m : sentMessages) {
            report.append(num++).append(".\n")
                  .append("ID       : ").append(m.getId()).append("\n")
                  .append("Hash     : ").append(m.getMessageHash()).append("\n")
                  .append("Recipient: ").append(m.getRecipient()).append("\n")
                  .append("Content  : ").append(m.getContent()).append("\n")
                  .append("Time     : ").append(m.getTimestamp()).append("\n")
                  .append("────────────────────────────────────\n");
        }
        JOptionPane.showMessageDialog(null, report.toString());
    }

    // ==================== Save & Exit ====================
    private void saveAndExit() {
        int choice = JOptionPane.showConfirmDialog(null,
            "Do you want to save all messages to JSON before exiting?",
            "Exit", JOptionPane.YES_NO_OPTION);

        if (choice == JOptionPane.YES_OPTION) {
            Message.storeMessage(sentMessages, storedMessages);
        }
        JOptionPane.showMessageDialog(null,
            "Thank you for using QuickChat!\nGoodbye " + fullName + "!", 
            "See you soon!", JOptionPane.INFORMATION_MESSAGE);
    }

    // Getters (optional, for future use)
    public ArrayList<Message> getSentMessages() { return sentMessages; }
    public ArrayList<Message> getDisregardedMessages() { return disregardedMessages; }
    public ArrayList<Message> getStoredMessages() { return storedMessages; }
    public ArrayList<String> getMessageHashes() { return messageHashes; }
    public ArrayList<String> getMessageIDs() { return messageIDs; }
}
