/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package portforlio.pkg3;

import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_Lab
 */
public class LoggedinIT {
    
  private Loggedin app;
    private ArrayList<Message> sent;
    private ArrayList<Message> stored;
    private ArrayList<Message> disregarded;

    @BeforeEach
    void setUp() {
        app = new Loggedin("test_user", "Test User");
        
        // Reflect private fields to populate with test data
        sent = app.getSentMessages();
        stored = app.getStoredMessages();
        disregarded = app.getDisregardedMessages();

        // Clear any previous data
        sent.clear();
        stored.clear();
        disregarded.clear();
        app.getMessageHashes().clear();
        app.getMessageIDs().clear();

        // === LOAD EXACT TEST DATA FROM YOUR POE ===
        
        // Test Data Message 1 - Sent
        Message m1 = new Message("Did you get the cake?", "+27834557896");
        sent.add(m1);
        app.getMessageIDs().add(m1.getId());
        app.getMessageHashes().add(m1.getMessageHash());
        Message.incrementTotalMessagesSent();

        // Test Data Message 2 - Stored
        Message m2 = new Message("Where are you? You are late! I have asked you to be on time.", "+27838884567");
        stored.add(m2);
        app.getMessageIDs().add(m2.getId());
        app.getMessageHashes().add(m2.getMessageHash());

        // Test Data Message 3 - Disregarded
        Message m3 = new Message("Yohoooo, I am at your gate.", "+27834484567");
        disregarded.add(m3);
        app.getMessageIDs().add(m3.getId());
        app.getMessageHashes().add(m3.getMessageHash());

        // Test Data Message 4 - Sent
        Message m4 = new Message("It is dinner time !", "0838884567"); // Note: invalid number on purpose? Still added as sent
        sent.add(m4);
        app.getMessageIDs().add(m4.getId());
        app.getMessageHashes().add(m4.getMessageHash());
        Message.incrementTotalMessagesSent();

        // Test Data Message 5 - Stored
        Message m5 = new Message("Ok, I am leaving without you.", "+27838884567");
        stored.add(m5);
        app.getMessageIDs().add(m5.getId());
        app.getMessageHashes().add(m5.getMessageHash());
    }

    @Test
    void testSentMessagesArrayPopulatedCorrectly() {
        assertEquals(2, sent.size(), "Sent Messages array should contain exactly 2 messages");
        assertTrue(sent.stream().anyMatch(m -> m.getContent().contains("Did you get the cake?")));
        assertTrue(sent.stream().anyMatch(m -> m.getContent().contains("It is dinner time")));
    }

    @Test
    void testDisplayLongestSentMessage() {
        // The longest should be Message 2 (stored), but we only check sent → Message 1 is longest in sent
        // In your test data, only Message 1 and 4 are sent → Message 1 is longer
        Message longestInSent = sent.get(0);
        for (Message m : sent) {
            if (m.getContent().length() > longestInSent.getContent().length()) {
                longestInSent = m;
            }
        }
        assertTrue(longestInSent.getContent().contains("Did you get the cake?") ||
                   longestInSent.getContent().contains("It is dinner time !"),
                   "Longest sent message should be one of the two sent ones");
    }

    @Test
    void testSearchForMessageID() {
        // Search for Message 4 ID (the developer one)
        Message developerMsg = sent.get(1); // Message 4
        String idToSearch = developerMsg.getId();

        Message found = null;
        for (Message m : sent) {
            if (m.getId().equals(idToSearch)) {
                found = m;
                break;
            }
        }

        assertNotNull(found, "Message ID search should find the developer message");
        assertEquals("It is dinner time !", found.getContent().trim());
    }

    @Test
    void testSearchAllMessagesByRecipient() {
        String recipient = "+27838884567";
        ArrayList<Message> results = new ArrayList<>();
        
        // Search in both sent and stored (as per requirement)
        for (Message m : sent) {
            if (m.getRecipient().equals(recipient)) results.add(m);
        }
        for (Message m : stored) {
            if (m.getRecipient().equals(recipient)) results.add(m);
        }

        assertEquals(2, results.size(), "Should find 2 messages for +27838884567");
        assertTrue(results.stream().anyMatch(m -> m.getContent().contains("Where are you")));
        assertTrue(results.stream().anyMatch(m -> m.getContent().contains("Ok, I am leaving")));
    }

    @Test
    void testDeleteMessageUsingHashOrID() {
        // We'll delete Message 2 using its hash (stored message)
        Message toDelete = stored.get(0); // "Where are you..." message
        String hash = toDelete.getMessageHash();

        boolean removed = false;
        if (stored.removeIf(m -> m.getMessageHash().equals(hash))) {
            removed = true;
        } else if (sent.removeIf(m -> m.getMessageHash().equals(hash))) {
            removed = true;
        }

        assertTrue(removed, "Message with hash from Test Message 2 should be deletable");
        assertFalse(stored.stream().anyMatch(m -> m.getMessageHash().equals(hash)),
                    "Message 'Where are you? You are late...' should be successfully deleted");
    }

    @Test
    void testDisplayReportContainsRequiredFields() {
        StringBuilder report = new StringBuilder();
        int num = 1;
        for (Message m : sent) {
            report.append(num++).append(".\n")
                  .append("Message Hash : ").append(m.getMessageHash()).append("\n")
                  .append("Recipient    : ").append(m.getRecipient()).append("\n")
                  .append("Message      : ").append(m.getContent()).append("\n");
        }

        String reportStr = report.toString();

        assertTrue(reportStr.contains("Message Hash"), "Report must include Message Hash");
        assertTrue(reportStr.contains("Recipient"), "Report must include Recipient");
        assertTrue(reportStr.contains("Did you get the cake?") || reportStr.contains("It is dinner time"),
                   "Report must include the actual sent messages");
    }
} 
    